Gita Wallpaper (Hindi - Tall)

1. Extract this zip.
2. Run install.bat.
