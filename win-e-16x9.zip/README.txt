Gita Wallpaper (English - Standard)

1. Extract this zip.
2. Run install.bat.
