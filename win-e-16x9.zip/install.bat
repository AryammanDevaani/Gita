
@echo off
echo Installing Gita Wallpaper Updater...
cd /d "%~dp0"
powershell.exe -ExecutionPolicy Bypass -File "register.ps1"
echo.
echo Running first update now...
powershell.exe -ExecutionPolicy Bypass -File "updwp.ps1"
pause
