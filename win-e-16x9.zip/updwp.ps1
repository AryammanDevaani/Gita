
# Configuration
$url = "https://raw.githubusercontent.com/aryammandevaani/gita/main/wallpapers/epc16x9.png"
$dest = "$env:USERPROFILE\Pictures\gita-daily.png"

# 1. Download the Image
Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing

# 2. Set the Wallpaper
$code = @'
using System.Runtime.InteropServices;
public class Wallpaper {
   [DllImport("user32.dll", CharSet=CharSet.Auto)]
   public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
}
'@
Add-Type -TypeDefinition $code -MemberDefinition '[DllImport("user32.dll")] public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);' -Name Win32 -Namespace Wallpaper

[Wallpaper.Win32]::SystemParametersInfo(0x0014, 0, $dest, 0x0001 -bor 0x0002)
