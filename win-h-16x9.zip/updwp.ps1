
# Configuration
$url = "https://raw.githubusercontent.com/aryammandevaani/gita/main/wallpapers/hpc16x9.png"
$dest = "$env:USERPROFILE\Pictures\gita-daily.png"

Write-Host "Starting Gita Wallpaper Update..." -ForegroundColor Cyan

# 1. Force Delete old file (To ensure Windows sees the change)
if (Test-Path $dest) { 
    Remove-Item $dest -Force 
}

# 2. Download the Image
try {
    Write-Host "Downloading from GitHub..." -ForegroundColor Gray
    Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing
    Write-Host "Download successful." -ForegroundColor Green
}
catch {
    Write-Host "Download failed: $_" -ForegroundColor Red
    Write-Host "Check your internet connection."
    exit
}

# 3. Set the Wallpaper
Write-Host "Setting wallpaper..." -ForegroundColor Cyan

$code = @'
using System.Runtime.InteropServices;
public class Wallpaper {
   [DllImport("user32.dll", CharSet=CharSet.Auto)]
   public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
}
'@

# FIXED: Removed extra parameters that caused the ambiguity error
Add-Type -TypeDefinition $code 

# FIXED: Called the class directly as "Wallpaper"
[Wallpaper]::SystemParametersInfo(0x0014, 0, $dest, 0x0001 -bor 0x0002)

Write-Host "Done! Wallpaper updated." -ForegroundColor Green
