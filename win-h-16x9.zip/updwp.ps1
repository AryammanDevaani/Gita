
# Configuration
$url = "https://raw.githubusercontent.com/aryammandevaani/gita/main/wallpapers/hpc16x9.png"
$dest = "$env:USERPROFILE\Pictures\gita-daily.png"

# Smart Check 1: Stop if already updated today
if (Test-Path $dest) {
    $file = Get-Item $dest
    if ($file.LastWriteTime.Date -eq (Get-Date).Date) { exit }
}

# Smart Check 2: Stop if no internet
if (-not (Test-Connection -ComputerName github.com -Quiet -Count 1)) { exit }

# Download
Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing

# Set Wallpaper
$code = @'
using System.Runtime.InteropServices;
public class Wallpaper {
   [DllImport("user32.dll", CharSet=CharSet.Auto)]
   public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
}
'@
Add-Type -TypeDefinition $code -MemberDefinition '[DllImport("user32.dll")] public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);' -Name Win32 -Namespace Wallpaper
[Wallpaper.Win32]::SystemParametersInfo(0x0014, 0, $dest, 0x0001 -bor 0x0002)
