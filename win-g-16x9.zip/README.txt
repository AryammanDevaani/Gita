Gita Wallpaper (Gujarati - Standard)

1. Extract this zip.
2. Run install.bat.
