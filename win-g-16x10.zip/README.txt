Gita Wallpaper (Gujarati - Tall)

1. Extract this zip.
2. Run install.bat.
