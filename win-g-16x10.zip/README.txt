Gita Wallpaper (Gujarati)

1. Extract this zip.
2. Run install.bat.