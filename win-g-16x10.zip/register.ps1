
$taskName = "GitaWallpaper"
$scriptPath = "$PSScriptRoot\updwp.ps1"

# Unregister old task if it exists
Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue

# Build the argument string safely
$argStr = "-ExecutionPolicy Bypass -WindowStyle Hidden -File " + [char]34 + $scriptPath + [char]34

# 1. Action
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $argStr

# 2. Trigger (Logon + 15 min repeat)
$trigger = New-ScheduledTaskTrigger -AtLogOn -RepetitionInterval (New-TimeSpan -Minutes 15)
$trigger.Repetition.Duration = [TimeSpan]::Zero 

# 3. Settings (Network Required)
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RunOnlyIfNetworkAvailable

# 4. Register
Register-ScheduledTask -Action $action -Trigger $trigger -Settings $settings -TaskName $taskName -Description "Daily Gita Wallpaper (Smart Poll)"

Write-Host "Success! Task installed." -ForegroundColor Green
Start-Sleep -Seconds 3
